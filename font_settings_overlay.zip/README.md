# 字体设置补丁（基于 WeType_UI_Enhanced 1.29.0）

给模块设置页的「共享设置」分组新增两项：

1. **使用 SF Pro 字体**（开关，默认开）：关闭后恢复微信输入法原版字体与按键图标。
2. **字体粗细**（滑块，-100 ~ +300，步进 25，默认 0）：在宿主请求字重上叠加补偿，例如 +100 让 400 的文字按 500 渲染；开关关闭时滑块禁用。

关闭字体时不会让按键变空白：宿主的 `createFromAsset` hook 拿不到替换值会走原逻辑，`WeTypeKeyboardSymbols` 里所有绘制失败都会 `chain.proceed()` 回退到原生绘制。保存后建议用设置页的「重启输入法」重启一次。

## GitHub Actions 出包（推荐，无需本地 git）

本机没有 JDK / Gradle / Android SDK，所以编译放在 GitHub 的 runner 上做。全程可以只在网页上操作：

1. 打开 https://github.com/NEORUAA/WeType_UI_Enhanced ，点 **Fork**（保持默认 `main` 分支）。
2. 在自己的 fork 里 **Add file → Upload files**，把 `font_settings_overlay.zip` 上传到仓库根目录，提交。
3. 再 **Add file → Create new file**，文件名填 `.github/workflows/build.yml`，把 `build.yml` 的内容整段粘贴进去，提交。
   （也可以把这两个文件放在同一次提交里。）
4. 若 Actions 页面提示 fork 的工作流未启用，点 **I understand my workflows, go ahead and enable them**。
5. 进入 **Actions → Build module APK**，等这次 push 触发的运行结束（也可 `workflow_dispatch` 手动重跑）。
   CI 会自动解压 zip、覆盖源码、装好 JDK 21 与 Android SDK，然后 `./gradlew :app:assembleRelease`。
6. 运行成功后，在该次运行页面底部下载 artifact `wetype-ui-enhanced-font-settings`，解压得到 `WeType_UI_Enhanced-1.29.0_release.apk`。

**拿到 APK 后**：它是未签名包（仓库没配签名）。用手机端 MT管理器 / NP管理器做 v2+v3 签名 → 先卸载已装的官方模块 → 安装签名后的包 → LSPosed 重新启用并勾选微信输入法 → 重启输入法。签名与原版不同，不能直接覆盖安装。

备选：本地 Android Studio 打开 fork，把 zip 里的 `app/` 覆盖进去，直接 Build APK；或用 `font_settings.patch` 在 fork 里 `git apply` 后自行构建。

## 改了什么

| 文件 | 改动 |
|---|---|
| `wetype/settings/WeTypeSettings.kt` | 新增 `use_sf_pro_font` / `font_weight_adjust` 两个偏好键、`Profiles` 字段、读写与范围约束，以及供渲染层读取的 `currentFontConfig()` |
| `wetype/graphics/SfSymbols.kt` | 渲染入口统一读取配置：关闭时返回 `null`，开启时把补偿值加到 `wght` |
| `MainActivity.kt` | 「共享设置」分组加入开关与滑块，保存时写入两个字段 |
| `res/values*/strings*.xml` | 中英文文案 |

共 5 个文件、+54/-5 行。`git apply --check` 与实际 apply 均通过，XML 合法、改动片段齐全、括号平衡；**未经 Kotlin 编译和真机验证**，若 CI 报编译错误，把日志发回来即可修正。

## 注意

- 项目是 **AGPL-3.0**：自用没问题；公开分发改动后的 APK 需按同协议公开源码。用 fork + 上传 zip 的方式，改动文件本身就在公开仓库里，符合这一要求。
- `compileSdk = 37`。工作流已做兜底：若 runner 装不到 `platforms;android-37`，会自动改用 36 并补上 `android.suppressUnsupportedCompileSdk=36`。
- CI 每次都会从 zip 重新应用改动，所以 zip 和 workflow 要一起留在仓库里；上游更新后只要重新 fork/同步即可。
- 项目的 `settings.gradle.kts` 依赖 `maven("https://api.xposed.info/")` 拉取 `io.github.libxposed:*`。若 CI 报 `Could not resolve io.github.libxposed`，多为该仓库临时不可达：先重跑一次；长期不可达需在 `settings.gradle.kts` 的 `dependencyResolutionManagement.repositories` 里换镜像（该文件设置了 `FAIL_ON_PROJECT_REPOS`，不能在 `app/build.gradle.kts` 里加仓库）。
